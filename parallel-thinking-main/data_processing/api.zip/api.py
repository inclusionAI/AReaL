from dotenv import load_dotenv
import os
from openai import OpenAI
# This code loads the OpenAI API key and base URL from environment variables using the dotenv package.
# It ensures that sensitive information is not hardcoded in the script, enhancing security.

from dotenv import load_dotenv
from problem import problem, problem2, problem3, CoT_solution, CoT_solution_2, CoT_solution_3, problem4, CoT_solution_4, problem5, CoT_solution_5
import os
load_dotenv()
openai_api_key = os.environ.get("INFINI_API_KEY")
openai_base_url = os.environ.get("INFINI_BASE_URL")
silicon_api_key = os.environ.get("SILICON_API_KEY")
silicon_base_url = os.environ.get("SILICON_BASE_URL")

print(openai_base_url)  
client = OpenAI(api_key=openai_api_key, base_url=openai_base_url)

# You can choose a model from the following list
# Or you can log into your Infini-AI or SiliconFlow account, and find an available model you want to use.
# model = "Qwen/QVQ-72B-Preview"
# model="llama-3.3-70b-instruct"
model="deepseek-v3"

user_content = f"Problem: {problem}\nCoT solution: {CoT_solution}"
response = client.chat.completions.create(
  model=model,
  temperature=0,
  messages=[
    {"role": "system", "content": "You are a helpful assistant for math problems thinking process analysis. The user will give you a math problem and its CoT solution by LLM. You need to analyze the CoT solution and divide the solution into several steps, each thought process (like calculation, recalling theorems, reflection, etc) should be regarded as a single step. There should never be substeps under each step. Make the steps has as small granularity as possible. For each step, you need to give a short description of what the model do."},
    {"role": "user", "content": user_content}
  ]
)

print(response.choices[0].message.content)
print("Dependency analysis:")
dependency_analysis = response.choices[0].message.content
response = client.chat.completions.create(
  model=model,
  temperature=0,
  messages=[
    {"role": "system", "content": "The user want to do math problem in parallel. Please analyze the dependency of each step in the solution process given by the user. The output result should be a list of tuples, each tuple should be a pair of step index and where the first step depends on the second step. As the user need to do math problem in parallel, please make the dependency as small as possible. "},
    {"role": "user", "content": f"Please analyze the dependency of each step in the following thought process: {dependency_analysis}. "}
  ]
)
print(response.choices[0].message.content)