# Periodic RoPE Implementation - Usage Guide

## Overview

This implementation provides a new method for extending positional encoding beyond the original context length using a **periodic wrapping** approach.

**Key Idea**: For any position `m > L` (where L is the period length, default 32768), we use `m % L` for the RoPE encoding. This means the positional encoding pattern repeats with period L.

## Implementation Files

- **`scaled_rope/LlamaPeriodicRotaryEmbedding.py`** - Contains two classes:
  - `LlamaPeriodicRotaryEmbedding` - Precomputes the full period upfront
  - `LlamaDynamicPeriodicRotaryEmbedding` - Dynamically expands cache as needed

## How to Use with YaRN Training Code

### Method 1: Quick Test (Modify modeling file)

Edit `scaled_rope/modeling_llama_yarn.py` to add support for periodic RoPE:

1. **Import the new class** (add at the top after other imports):
```python
from .LlamaPeriodicRotaryEmbedding import LlamaPeriodicRotaryEmbedding, LlamaDynamicPeriodicRotaryEmbedding
```

2. **Add to `_init_rope` method** (around line 468, add a new elif case):
```python
elif scaling_type == "periodic":
    period_length = self.config.rope_scaling.get("period_length", 32768)
    self.rotary_emb = LlamaPeriodicRotaryEmbedding(
        self.head_dim,
        max_position_embeddings=self.max_position_embeddings,
        base=self.rope_theta,
        period_length=period_length
    )
elif scaling_type == "dynamic-periodic":
    period_length = self.config.rope_scaling.get("period_length", 32768)
    self.rotary_emb = LlamaDynamicPeriodicRotaryEmbedding(
        self.head_dim,
        max_position_embeddings=self.max_position_embeddings,
        base=self.rope_theta,
        period_length=period_length
    )
```

3. **Configure your model** with rope_scaling config:
```python
rope_scaling = {
    "type": "periodic",  # or "dynamic-periodic"
    "factor": 4.0,  # Not used by periodic, but kept for compatibility
    "period_length": 32768  # The period L for wrapping
}
```

### Method 2: Direct Usage in Training Script

If you want to test without modifying the modeling file:

```python
from scaled_rope.LlamaPeriodicRotaryEmbedding import LlamaPeriodicRotaryEmbedding

# Create the embedding
rotary_emb = LlamaPeriodicRotaryEmbedding(
    dim=128,  # head_dim
    max_position_embeddings=2048,  # initial cache size
    base=10000,  # RoPE base (theta)
    period_length=32768,  # L - the wrapping period
    device='cuda'
)

# Use in forward pass
cos, sin = rotary_emb(x, seq_len=65536)  # Can handle sequences > period_length
```

## Configuration Examples

### Example 1: Train with 32K period (default)
```python
config = {
    "rope_scaling": {
        "type": "periodic",
        "period_length": 32768
    }
}
```

### Example 2: Train with 8K period
```python
config = {
    "rope_scaling": {
        "type": "periodic",
        "period_length": 8192
    }
}
```

### Example 3: Dynamic periodic (saves memory)
```python
config = {
    "rope_scaling": {
        "type": "dynamic-periodic",
        "period_length": 32768
    }
}
```

## Differences Between Static and Dynamic Versions

### `LlamaPeriodicRotaryEmbedding` (Static)
- **Pros**: 
  - Precomputes entire period upfront
  - Faster for sequences that frequently use full period
  - No recomputation needed
- **Cons**: 
  - Uses more memory (stores full period)
  - Initial setup is slower
- **Use when**: You know you'll need long sequences frequently

### `LlamaDynamicPeriodicRotaryEmbedding` (Dynamic)
- **Pros**: 
  - Starts with small cache
  - Saves memory for short sequences
  - Expands only as needed
- **Cons**: 
  - May recompute cache during training
  - Slightly slower for first long sequence
- **Use when**: Sequence lengths vary or you want to save memory

## How It Works

1. **For positions 0 to L-1**: Uses standard RoPE encoding
2. **For positions >= L**: Uses `position % L` to index into the cached encodings

Example with L=32768:
- Position 0 → uses encoding[0]
- Position 32767 → uses encoding[32767]
- Position 32768 → uses encoding[0] (wraps around)
- Position 65536 → uses encoding[0] (wraps around)
- Position 100000 → uses encoding[100000 % 32768] = encoding[2768]

## Training Tips

1. **Choose period_length wisely**:
   - Should be >= your base model's trained context length
   - Common choices: 8192, 16384, 32768, 65536
   - Larger periods = more unique positions before wrapping

2. **Training data**:
   - Include sequences that exceed the period_length
   - This helps the model learn to handle wrapped positions

3. **Comparison with YaRN**:
   - YaRN: Complex interpolation/extrapolation with smooth blending
   - Periodic: Simple modulo operation, no parameter tuning
   - Periodic: May require more training to handle discontinuities at wrap points

## Example Training Command

```bash
# Modify your train.sh to use periodic RoPE
python finetune.py \
    --model_name_or_path meta-llama/Llama-2-7b-hf \
    --rope_scaling_type periodic \
    --rope_period_length 32768 \
    --max_position_embeddings 65536 \
    --per_device_train_batch_size 1 \
    --gradient_accumulation_steps 8 \
    ...
```

## Testing Your Implementation

Quick test to verify it works:

```python
import torch
from scaled_rope.LlamaPeriodicRotaryEmbedding import LlamaPeriodicRotaryEmbedding

# Create embedding
emb = LlamaPeriodicRotaryEmbedding(dim=64, period_length=100, device='cpu')

# Test wrapping
x = torch.randn(1, 8, 150, 64)  # seq_len=150 > period=100
cos, sin = emb(x, seq_len=150)

# Verify periodicity: position 0 should equal position 100
print("Position 0 matches position 100:", torch.allclose(cos[0], cos[100]))
# Should print: True

# Verify position 50 matches position 150
print("Position 50 matches position 150:", torch.allclose(cos[50], cos[100]))  
# Should print: True
```

## Next Steps

1. Modify `modeling_llama_yarn.py` to add periodic RoPE support (see Method 1)
2. Update your training configuration
3. Run training with your periodic positional encoding
4. Compare perplexity and downstream task performance with YaRN

## Questions?

The implementation is in: `scaled_rope/LlamaPeriodicRotaryEmbedding.py`

Key advantages of periodic approach:
- ✅ Simpler than YaRN (no interpolation/extrapolation math)
- ✅ No hyperparameter tuning (beta_fast, beta_slow, etc.)
- ✅ Memory efficient (only stores one period)
- ✅ Deterministic wrapping behavior

Potential challenges:
- ⚠️ Discontinuity at wrap points (position L-1 to L)
- ⚠️ May need more training data to learn periodic pattern
- ⚠️ Unknown if it performs as well as YaRN's smooth interpolation
