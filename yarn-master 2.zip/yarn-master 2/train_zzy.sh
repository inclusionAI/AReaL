accelerate launch finetune.py \
    --output-dir output/yarn-7b-64k-zzy-10-data-16384 \
    --model /storage/openpsi/models/llama-2-7b-hf/daryl149__llama-2-7b-chat-hf\
    --scaling-type  periodic \
    --scaling-factor 16.0 \
    --truncate 16384 \
    --batch-size 1 \
    --gradient-accumulate-every 8 \
    --max-train-steps 100 \
    --deepspeed