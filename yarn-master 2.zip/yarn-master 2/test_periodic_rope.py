"""
Test script for Periodic RoPE implementation
Run this to verify the periodic wrapping works correctly
"""

import torch
import sys
sys.path.insert(0, '/Users/zzy/Downloads/yarn-master')

from scaled_rope.LlamaPeriodicRotaryEmbedding import (
    LlamaPeriodicRotaryEmbedding,
    LlamaDynamicPeriodicRotaryEmbedding
)

def test_periodic_wrapping():
    """Test that positions wrap correctly with period L"""
    print("=" * 60)
    print("Test 1: Periodic Wrapping Verification")
    print("=" * 60)
    
    period_length = 100
    dim = 64
    
    # Create embedding
    emb = LlamaPeriodicRotaryEmbedding(
        dim=dim,
        period_length=period_length,
        device='cpu'
    )
    
    # Create dummy input
    seq_len = 250  # More than 2 periods
    x = torch.randn(1, 8, seq_len, dim)
    
    # Get cos/sin
    cos, sin = emb(x, seq_len=seq_len)
    
    print(f"Period length: {period_length}")
    print(f"Sequence length: {seq_len}")
    print(f"Cos/Sin shape: {cos.shape}")
    
    # Test periodicity
    tests = [
        (0, 100, "pos 0 == pos 100"),
        (0, 200, "pos 0 == pos 200"),
        (50, 150, "pos 50 == pos 150"),
        (99, 199, "pos 99 == pos 199"),
    ]
    
    all_passed = True
    for pos1, pos2, description in tests:
        cos_match = torch.allclose(cos[pos1], cos[pos2], atol=1e-6)
        sin_match = torch.allclose(sin[pos1], sin[pos2], atol=1e-6)
        passed = cos_match and sin_match
        all_passed = all_passed and passed
        
        status = "✓ PASS" if passed else "✗ FAIL"
        print(f"{status}: {description}")
        if not passed:
            print(f"  cos max diff: {(cos[pos1] - cos[pos2]).abs().max().item()}")
            print(f"  sin max diff: {(sin[pos1] - sin[pos2]).abs().max().item()}")
    
    print()
    if all_passed:
        print("✓ All periodicity tests PASSED!")
    else:
        print("✗ Some tests FAILED!")
    
    return all_passed


def test_dynamic_vs_static():
    """Test that dynamic and static versions produce same output"""
    print("\n" + "=" * 60)
    print("Test 2: Dynamic vs Static Implementation")
    print("=" * 60)
    
    period_length = 32768
    dim = 128
    seq_len = 65536
    
    # Create both versions
    static_emb = LlamaPeriodicRotaryEmbedding(
        dim=dim,
        period_length=period_length,
        device='cpu'
    )
    
    dynamic_emb = LlamaDynamicPeriodicRotaryEmbedding(
        dim=dim,
        period_length=period_length,
        device='cpu'
    )
    
    # Create dummy input
    x = torch.randn(1, 8, seq_len, dim)
    
    # Get outputs
    print(f"Testing with seq_len={seq_len}, period={period_length}")
    static_cos, static_sin = static_emb(x, seq_len=seq_len)
    dynamic_cos, dynamic_sin = dynamic_emb(x, seq_len=seq_len)
    
    # Compare
    cos_match = torch.allclose(static_cos, dynamic_cos, atol=1e-6)
    sin_match = torch.allclose(static_sin, dynamic_sin, atol=1e-6)
    
    if cos_match and sin_match:
        print("✓ PASS: Static and Dynamic implementations match!")
    else:
        print("✗ FAIL: Implementations differ!")
        print(f"  cos max diff: {(static_cos - dynamic_cos).abs().max().item()}")
        print(f"  sin max diff: {(static_sin - dynamic_sin).abs().max().item()}")
    
    return cos_match and sin_match


def test_short_sequences():
    """Test that short sequences (< period) work correctly"""
    print("\n" + "=" * 60)
    print("Test 3: Short Sequences (< period_length)")
    print("=" * 60)
    
    period_length = 32768
    dim = 128
    seq_len = 2048  # Much shorter than period
    
    emb = LlamaPeriodicRotaryEmbedding(
        dim=dim,
        period_length=period_length,
        device='cpu'
    )
    
    x = torch.randn(1, 8, seq_len, dim)
    cos, sin = emb(x, seq_len=seq_len)
    
    print(f"Period length: {period_length}")
    print(f"Sequence length: {seq_len}")
    print(f"Output shape: {cos.shape}")
    
    # Check shape
    if cos.shape[0] == seq_len and sin.shape[0] == seq_len:
        print("✓ PASS: Correct output shape for short sequences")
        return True
    else:
        print("✗ FAIL: Incorrect output shape")
        return False


def test_memory_efficiency():
    """Show memory usage of different approaches"""
    print("\n" + "=" * 60)
    print("Test 4: Memory Efficiency Analysis")
    print("=" * 60)
    
    dim = 128
    period_length = 32768
    
    # Static version
    static_emb = LlamaPeriodicRotaryEmbedding(
        dim=dim,
        period_length=period_length,
        device='cpu'
    )
    
    # Dynamic version
    dynamic_emb = LlamaDynamicPeriodicRotaryEmbedding(
        dim=dim,
        max_position_embeddings=2048,  # Start small
        period_length=period_length,
        device='cpu'
    )
    
    static_size = static_emb.cos_cached.numel() + static_emb.sin_cached.numel()
    dynamic_size = dynamic_emb.cos_cached.numel() + dynamic_emb.sin_cached.numel()
    
    print(f"Dimension: {dim}")
    print(f"Period length: {period_length}")
    print(f"\nStatic version cached elements: {static_size:,}")
    print(f"Dynamic version cached elements: {dynamic_size:,}")
    print(f"Memory ratio (static/dynamic): {static_size/dynamic_size:.2f}x")
    
    print("\n✓ Both versions working (memory usage as expected)")
    return True


def benchmark_performance():
    """Simple performance comparison"""
    print("\n" + "=" * 60)
    print("Test 5: Performance Benchmark")
    print("=" * 60)
    
    import time
    
    period_length = 32768
    dim = 128
    seq_len = 65536
    num_iterations = 100
    
    # Create embeddings
    static_emb = LlamaPeriodicRotaryEmbedding(
        dim=dim,
        period_length=period_length,
        device='cpu'
    )
    
    dynamic_emb = LlamaDynamicPeriodicRotaryEmbedding(
        dim=dim,
        period_length=period_length,
        device='cpu'
    )
    
    x = torch.randn(1, 8, seq_len, dim)
    
    # Warm up
    _ = static_emb(x, seq_len=seq_len)
    _ = dynamic_emb(x, seq_len=seq_len)
    
    # Benchmark static
    start = time.time()
    for _ in range(num_iterations):
        _ = static_emb(x, seq_len=seq_len)
    static_time = time.time() - start
    
    # Benchmark dynamic
    start = time.time()
    for _ in range(num_iterations):
        _ = dynamic_emb(x, seq_len=seq_len)
    dynamic_time = time.time() - start
    
    print(f"Iterations: {num_iterations}")
    print(f"Sequence length: {seq_len}")
    print(f"\nStatic version: {static_time*1000:.2f}ms total ({static_time/num_iterations*1000:.3f}ms per iteration)")
    print(f"Dynamic version: {dynamic_time*1000:.2f}ms total ({dynamic_time/num_iterations*1000:.3f}ms per iteration)")
    print(f"Speedup: {dynamic_time/static_time:.2f}x")
    
    print("\n✓ Performance test completed")
    return True


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("PERIODIC ROPE IMPLEMENTATION TEST SUITE")
    print("=" * 60)
    
    results = []
    
    try:
        results.append(("Periodic Wrapping", test_periodic_wrapping()))
    except Exception as e:
        print(f"✗ Test failed with error: {e}")
        results.append(("Periodic Wrapping", False))
    
    try:
        results.append(("Dynamic vs Static", test_dynamic_vs_static()))
    except Exception as e:
        print(f"✗ Test failed with error: {e}")
        results.append(("Dynamic vs Static", False))
    
    try:
        results.append(("Short Sequences", test_short_sequences()))
    except Exception as e:
        print(f"✗ Test failed with error: {e}")
        results.append(("Short Sequences", False))
    
    try:
        results.append(("Memory Efficiency", test_memory_efficiency()))
    except Exception as e:
        print(f"✗ Test failed with error: {e}")
        results.append(("Memory Efficiency", False))
    
    try:
        results.append(("Performance", benchmark_performance()))
    except Exception as e:
        print(f"✗ Test failed with error: {e}")
        results.append(("Performance", False))
    
    # Summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    
    for test_name, passed in results:
        status = "✓ PASS" if passed else "✗ FAIL"
        print(f"{status}: {test_name}")
    
    total_passed = sum(1 for _, passed in results if passed)
    total_tests = len(results)
    
    print(f"\nTotal: {total_passed}/{total_tests} tests passed")
    
    if total_passed == total_tests:
        print("\n🎉 All tests PASSED! Periodic RoPE implementation is working correctly.")
    else:
        print(f"\n⚠️  {total_tests - total_passed} test(s) FAILED. Please review the implementation.")
