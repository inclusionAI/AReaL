import torch
import math

class LlamaPeriodicRotaryEmbedding(torch.nn.Module):
    """
    Periodic RoPE: For positions > L, use position % L to create periodic positional encoding.
    This allows extending context window by repeating the RoPE pattern with period L.
    
    Args:
        dim: Dimension of the rotary embedding
        max_position_embeddings: Maximum position for initial cache (default: 2048)
        base: Base for computing inverse frequencies (default: 10000)
        period_length: The period L for position wrapping (default: 32768)
        device: Device to place tensors on
    """
    def __init__(self, dim, max_position_embeddings=2048, base=10000, period_length=32768, device=None):
        super().__init__()

        self.dim = dim
        self.max_position_embeddings = max_position_embeddings
        self.base = base
        self.period_length = period_length
        
        # Compute inverse frequencies (same as standard RoPE)
        inv_freq = 1.0 / (self.base ** (torch.arange(0, self.dim, 2).float().to(device) / self.dim))
        self.register_buffer("inv_freq", inv_freq, persistent=False)

        # Build initial cache for positions up to period_length
        # This ensures we have the full periodic pattern cached
        self.max_seq_len_cached = self.period_length
        self._build_cos_sin_cache(self.max_seq_len_cached, device=device if device else self.inv_freq.device)

    def _build_cos_sin_cache(self, seq_len, device):
        """Build cos/sin cache for the periodic pattern"""
        # Only need to cache up to period_length since it repeats
        cache_len = min(seq_len, self.period_length)
        
        t = torch.arange(cache_len, device=device, dtype=self.inv_freq.dtype)
        freqs = torch.einsum("i,j->ij", t, self.inv_freq)
        # Different from paper, but it uses a different permutation in order to obtain the same calculation
        emb = torch.cat((freqs, freqs), dim=-1)
        
        dtype = torch.get_default_dtype()
        self.register_buffer("cos_cached", emb.cos().to(dtype), persistent=False)
        self.register_buffer("sin_cached", emb.sin().to(dtype), persistent=False)

    def forward(self, x, seq_len=None):
        """
        Forward pass - returns cos and sin values for positions 0 to seq_len-1
        For positions >= period_length, uses modulo to wrap around
        
        Args:
            x: Input tensor [bs, num_attention_heads, seq_len, head_size]
            seq_len: Sequence length (if None, inferred from x)
            
        Returns:
            Tuple of (cos, sin) tensors for positional encoding
        """
        # x: [bs, num_attention_heads, seq_len, head_size]
        if seq_len is None:
            seq_len = x.shape[2]
        
        # If seq_len <= period_length, just return the cached values directly
        if seq_len <= self.period_length:
            return (
                self.cos_cached[:seq_len].to(dtype=x.dtype),
                self.sin_cached[:seq_len].to(dtype=x.dtype),
            )
        
        # For seq_len > period_length, we need to tile/repeat the periodic pattern
        # Create position indices with modulo wrapping
        positions = torch.arange(seq_len, device=x.device, dtype=torch.long)
        wrapped_positions = positions % self.period_length
        
        # Index into the cached cos/sin using wrapped positions
        cos_output = self.cos_cached[wrapped_positions].to(dtype=x.dtype)
        sin_output = self.sin_cached[wrapped_positions].to(dtype=x.dtype)
        
        return (cos_output, sin_output)


class LlamaDynamicPeriodicRotaryEmbedding(torch.nn.Module):
    """
    Dynamic Periodic RoPE: Similar to LlamaPeriodicRotaryEmbedding but with dynamic caching.
    Only caches what's needed, expanding the cache as longer sequences are encountered.
    
    Args:
        dim: Dimension of the rotary embedding
        max_position_embeddings: Maximum position for initial cache (default: 2048)
        base: Base for computing inverse frequencies (default: 10000)
        period_length: The period L for position wrapping (default: 32768)
        device: Device to place tensors on
    """
    def __init__(self, dim, max_position_embeddings=2048, base=10000, period_length=32768, device=None):
        super().__init__()

        self.dim = dim
        self.max_position_embeddings = max_position_embeddings
        self.base = base
        self.period_length = period_length
        
        # Compute inverse frequencies (same as standard RoPE)
        inv_freq = 1.0 / (self.base ** (torch.arange(0, self.dim, 2).float().to(device) / self.dim))
        self.register_buffer("inv_freq", inv_freq, persistent=False)

        # Build initial cache - only cache up to max_position_embeddings initially
        self.max_seq_len_cached = min(max_position_embeddings, period_length)
        self._build_cos_sin_cache(self.max_seq_len_cached, device=device if device else self.inv_freq.device)

    def _build_cos_sin_cache(self, seq_len, device):
        """Build cos/sin cache - only need to cache up to period_length"""
        # Clamp to period_length since pattern repeats
        cache_len = min(seq_len, self.period_length)
        
        t = torch.arange(cache_len, device=device, dtype=self.inv_freq.dtype)
        freqs = torch.einsum("i,j->ij", t, self.inv_freq)
        # Different from paper, but it uses a different permutation in order to obtain the same calculation
        emb = torch.cat((freqs, freqs), dim=-1)
        
        dtype = torch.get_default_dtype()
        self.register_buffer("cos_cached", emb.cos().to(dtype), persistent=False)
        self.register_buffer("sin_cached", emb.sin().to(dtype), persistent=False)
        self.max_seq_len_cached = cache_len

    def forward(self, x, seq_len=None):
        """
        Forward pass with dynamic cache expansion
        
        Args:
            x: Input tensor [bs, num_attention_heads, seq_len, head_size]
            seq_len: Sequence length (if None, inferred from x)
            
        Returns:
            Tuple of (cos, sin) tensors for positional encoding
        """
        # x: [bs, num_attention_heads, seq_len, head_size]
        if seq_len is None:
            seq_len = x.shape[2]
        
        # Expand cache if needed (but only up to period_length)
        if seq_len > self.max_seq_len_cached and self.max_seq_len_cached < self.period_length:
            self._build_cos_sin_cache(seq_len, device=x.device)
        
        # If seq_len <= cached length, return directly
        if seq_len <= self.max_seq_len_cached:
            return (
                self.cos_cached[:seq_len].to(dtype=x.dtype),
                self.sin_cached[:seq_len].to(dtype=x.dtype),
            )
        
        # For seq_len > period_length, use modulo wrapping
        positions = torch.arange(seq_len, device=x.device, dtype=torch.long)
        wrapped_positions = positions % self.period_length
        
        # Index into the cached cos/sin using wrapped positions
        cos_output = self.cos_cached[wrapped_positions].to(dtype=x.dtype)
        sin_output = self.sin_cached[wrapped_positions].to(dtype=x.dtype)
        
        return (cos_output, sin_output)
